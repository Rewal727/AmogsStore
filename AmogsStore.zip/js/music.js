const audio = document.getElementById("music");
audio.volume = 0.4;